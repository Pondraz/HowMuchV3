package com.example.howmuchv2 // Pastikan ini sesuai dengan package Anda

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.os.SystemClock
import android.util.Log
import androidx.camera.core.ImageProxy
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.Rot90Op
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

// Kita tetap menggunakan data class ini
data class DetectionResult(val boundingBox: RectF, val text: String, val confidence: Float)

class ObjectDetectorHelper(
    val context: Context,
    val detectorListener: DetectorListener,
    var currentModel: String
) {
    private var interpreter: Interpreter? = null
    private var labels = listOf<String>()

    private var tensorWidth = 0
    private var tensorHeight = 0
    private var numElements = 0

    private var confidenceThreshold = 0.5f
    private var iouThreshold = 0.5f

    init {
        setupObjectDetector(currentModel)
    }

    fun setupObjectDetector(modelName: String) {
        try {
            val modelFilename = modelName
            val assetFileDescriptor = context.assets.openFd(modelFilename)
            val fileInputStream = FileInputStream(assetFileDescriptor.fileDescriptor)
            val fileChannel = fileInputStream.channel
            val startOffset = assetFileDescriptor.startOffset
            val declaredLength = assetFileDescriptor.declaredLength
            val modelBuffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)

            val options = Interpreter.Options()
            options.setNumThreads(4)
            interpreter = Interpreter(modelBuffer, options)

            val inputTensor = interpreter!!.getInputTensor(0)
            tensorWidth = inputTensor.shape()[1]
            tensorHeight = inputTensor.shape()[2]

            val outputTensor = interpreter!!.getOutputTensor(0)
            numElements = outputTensor.shape()[1] // Jumlah elemen (misal: 11)

            labels = context.assets.open("labels.txt").bufferedReader().readLines()
            Log.d("ObjectDetectorHelper", "Model $modelName loaded successfully.")
        } catch (e: Exception) {
            detectorListener.onError("Failed to initialize TFLite interpreter: ${e.message}")
            Log.e("ObjectDetectorHelper", "Error initializing interpreter", e)
        }
    }

    fun detect(imageProxy: ImageProxy) {
        if (interpreter == null) {
            imageProxy.close()
            return
        }

        val frameTime = SystemClock.uptimeMillis()
        val bitmap = imageProxy.toBitmap()

        val results = detect(bitmap)
        val inferenceTime = SystemClock.uptimeMillis() - frameTime

        detectorListener.onResults(
            results,
            inferenceTime,
            bitmap.height,
            bitmap.width
        )
        imageProxy.close()
    }

    private fun detect(frame: Bitmap): List<DetectionResult> {
        interpreter ?: return emptyList()

        val resizedBitmap = Bitmap.createScaledBitmap(frame, tensorWidth, tensorHeight, true)
        val byteBuffer = convertBitmapToByteBuffer(resizedBitmap)
        val output = Array(1) { FloatArray(8400) { 0f } } // Sesuaikan 8400 jika perlu

        // Alokasikan buffer untuk output mentah
        val outputBuffer = ByteBuffer.allocateDirect(1 * 8400 * numElements * 4)
        outputBuffer.order(ByteOrder.nativeOrder())

        interpreter?.run(byteBuffer, outputBuffer)

        return processOutput(outputBuffer, frame.width, frame.height)
    }

    private fun convertBitmapToByteBuffer(bitmap: Bitmap): ByteBuffer {
        val byteBuffer = ByteBuffer.allocateDirect(1 * tensorWidth * tensorHeight * 3 * 4)
        byteBuffer.order(ByteOrder.nativeOrder())
        val intValues = IntArray(tensorWidth * tensorHeight)
        bitmap.getPixels(intValues, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

        var pixel = 0
        for (i in 0 until tensorHeight) {
            for (j in 0 until tensorWidth) {
                val `val` = intValues[pixel++]
                byteBuffer.putFloat(((`val` shr 16) and 0xFF) / 255.0f)
                byteBuffer.putFloat(((`val` shr 8) and 0xFF) / 255.0f)
                byteBuffer.putFloat((`val` and 0xFF) / 255.0f)
            }
        }
        return byteBuffer
    }

    private fun processOutput(buffer: ByteBuffer, imageWidth: Int, imageHeight: Int): List<DetectionResult> {
        buffer.rewind()
        val outputShape = interpreter!!.getOutputTensor(0).shape()
        // [1, 11, 8400] -> 11 = 4 (box) + 7 (classes)
        val numClasses = outputShape[1] - 4
        val numDetections = outputShape[2]

        val detections = mutableListOf<DetectionResult>()

        for (i in 0 until numDetections) {
            var maxClassScore = 0f
            var bestClassIndex = -1

            // Cari kelas dengan skor tertinggi
            for (j in 0 until numClasses) {
                val classScore = buffer.getFloat((j + 4) * numDetections * 4 + i * 4)
                if (classScore > maxClassScore) {
                    maxClassScore = classScore
                    bestClassIndex = j
                }
            }

            if (maxClassScore > confidenceThreshold) {
                val cx = buffer.getFloat(0 * numDetections * 4 + i * 4)
                val cy = buffer.getFloat(1 * numDetections * 4 + i * 4)
                val w = buffer.getFloat(2 * numDetections * 4 + i * 4)
                val h = buffer.getFloat(3 * numDetections * 4 + i * 4)

                val left = (cx - w / 2)
                val top = (cy - h / 2)
                val right = (cx + w / 2)
                val bottom = (cy + h / 2)

                val boundingBox = RectF(left, top, right, bottom)
                val text = labels[bestClassIndex]
                detections.add(DetectionResult(boundingBox, text, maxClassScore))
            }
        }
        return applyNMS(detections)
    }

    private fun applyNMS(detections: List<DetectionResult>): List<DetectionResult> {
        val sortedDetections = detections.sortedByDescending { it.confidence }
        val selectedDetections = mutableListOf<DetectionResult>()
        val active = BooleanArray(sortedDetections.size) { true }
        var numActive = active.size

        for (i in sortedDetections.indices) {
            if (active[i]) {
                val boxA = sortedDetections[i]
                selectedDetections.add(boxA)
                if (numActive == 1) break

                for (j in (i + 1) until sortedDetections.size) {
                    if (active[j]) {
                        val boxB = sortedDetections[j]
                        if (calculateIoU(boxA.boundingBox, boxB.boundingBox) > iouThreshold) {
                            active[j] = false
                            numActive--
                            if (numActive == 0) break
                        }
                    }
                }
                if (numActive == 0) break
            }
        }
        return selectedDetections
    }

    private fun calculateIoU(boxA: RectF, boxB: RectF): Float {
        val xA = max(boxA.left, boxB.left)
        val yA = max(boxA.top, boxB.top)
        val xB = min(boxA.right, boxB.right)
        val yB = min(boxA.bottom, boxB.bottom)
        val intersectionArea = max(0f, xB - xA) * max(0f, yB - yA)
        val boxAArea = (boxA.right - boxA.left) * (boxA.bottom - boxA.top)
        val boxBArea = (boxB.right - boxB.left) * (boxB.bottom - boxB.top)
        return intersectionArea / (boxAArea + boxBArea - intersectionArea)
    }

    fun clearObjectDetector() {
        interpreter?.close()
        interpreter = null
    }

    interface DetectorListener {
        fun onError(error: String)
        fun onResults(
            results: List<DetectionResult>?,
            inferenceTime: Long,
            imageHeight: Int,
            imageWidth: Int
        )
    }
}
